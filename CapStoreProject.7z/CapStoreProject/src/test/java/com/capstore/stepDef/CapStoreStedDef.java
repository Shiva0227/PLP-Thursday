package com.capstore.stepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capstore.pom.Feedback;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CapStoreStedDef {
	WebDriver driver;
	Feedback page;
	
	@Given("^User is on Feedback Page$")
	public void user_is_on_signup_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sa17\\Documents\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(
				"C:\\Users\\sa17\\Desktop\\PLP Thu\\New folder\\CapStoreProject\\src\\test\\java\\com\\capstore\\html\\signup.component.html");
		driver.manage().window().maximize();
		page = PageFactory.initElements(driver, Feedback.class);
	}

	@When("^User leaves name empty$")
	public void user_leaves_firstname_empty() throws Throwable {
		 page.setName("");Thread.sleep(500);
		    page.setproductId("12445");Thread.sleep(500);
		    page.setfeedBack("Good Product");Thread.sleep(500);
		   
	}

	@When("^Clicks the submit button$")
	public void clicks_the_submit_button() throws Throwable {
		Thread.sleep(3000);
		page.setRequest();
	}

	@Then("^Display name Alert msg$")
	public void display_name_Alert_msg() throws Throwable {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}

	@Then("^Display productId Alert msg$")
	public void display_productid_Alert_msg() throws Throwable {
		page.setName("Shiva");Thread.sleep(500);
	    page.setproductId("");Thread.sleep(500);
	    page.setfeedBack("Good Product");Thread.sleep(500);
	    
	}

	@When("^User leaves feedback empty$")
	public void user_leaves_email_empty() throws Throwable {
		page.setName("Shiva");Thread.sleep(500);
	    page.setproductId("12445");Thread.sleep(500);
	    page.setfeedBack("");Thread.sleep(500);
	   
	}

	@Then("^Display feedback Alert msg$")
	public void display_feedback_Alert_msg() throws Throwable {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}
	@When("^User enter correct details$")
	public void user_enter_correct_details() throws Throwable {
	page.setName("Shiva");Thread.sleep(500);
	page.setproductId("12445");Thread.sleep(500);
		    page.setfeedBack("GoodProduct");Thread.sleep(500);

		}

	/*
	 * @When("^User enter correct details$") public void
	 * user_enter_correct_details() throws Throwable {
	 * page.setName("Shiva");Thread.sleep(500);
	 * page.setproductId("12445");Thread.sleep(500);
	 * page.setfeedBack("GoodProduct");Thread.sleep(500);
	 * 
	 * }
	 */

	@Then("^Display success message$")
	public void display_success_message() throws Throwable {
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}


}