package com.capstore.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
public class Feedback{

	WebDriver driver;

	@FindBy(how=How.NAME, using="name")
	@CacheLookup
	private WebElement name;

	@FindBy(how=How.NAME, using="productId")
	@CacheLookup
	private WebElement productId;

	@FindBy(how=How.NAME, using="feedBack")
	@CacheLookup
	private WebElement feedBack;

	

	
	@FindBy(how=How.NAME, using="request")
	@CacheLookup
	private WebElement request;
	public WebElement getRequest() {
		return request;
	}
	public void setRequest() {
		this.request.click();
	}
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getName() {
		return name;
	}
	public void setName(String Name) {
		this.name.sendKeys(Name);
	}
	public WebElement productId() {
		return productId;
	}
	public void setproductId(String productId) {
		this.productId.sendKeys(productId);
	}
	public WebElement getfeedBack() {
		return feedBack;
	}
	public void setfeedBack(String feedBack) {
		this.feedBack.sendKeys(feedBack);
	}
	
	
	
}