package com.capstore.runner;




import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\sa17\\Desktop\\PLP Thu\\New folder\\CapStoreProject\\src\\test\\java\\com\\capstore\\feature\\capstore.feature", glue = "com.capstore.stepDef",
plugin = {"pretty", "html:target/capstore" }, monochrome = true/*,tags="@smokeTest"*/)
public class TestRunner {

}
