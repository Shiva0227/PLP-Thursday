package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.capstore.dao.FeedbackRepository;
import com.capstore.model.FeedbackCommon;

public class FeedbackService {
	
	private final FeedbackRepository feedbackRepository;

	
	
	public List<FeedbackCommon> getAllFeedbacks() {
		return (List<FeedbackCommon>) feedbackRepository.findAll();
	}



	public FeedbackService(FeedbackRepository feedbackRepository) {
		
		this.feedbackRepository = feedbackRepository;
	}

	/*public void setStatus() {
		feedbackRepo.findAll().forEach(a -> a.setStatus("Disapproved"));
	}*/
	/* @PostMapping("/Feedback")
	    void save(@RequestBody FeedbackCommon feedback) {
	       feedbackRepository.save(feedback);
	    }*/
	
}
