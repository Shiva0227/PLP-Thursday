package com.capstore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="Feedbacks")
public class FeedbackCommon 
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int feedback_id;
	@Column(length=10)
    private int product_id;
	/*private int customer_id;*/
	
	/*@Column(length=10)
    private long merchant_id;
	
	@Column(length=10)
    private long product_rating;
	*/
	@Column(length=250)
    private String feedback;
/*	
	@Column(length=20)
    private String status;*/

	public long getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	
	
	
	

	public int getFeedback_id() {
		return feedback_id;
	}

	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}

	/*public int getCustomer_id() {
		return customer_id;
	}
*/
	/*public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}*/

	/*public long getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(long merchant_id) {
		this.merchant_id = merchant_id;
	}

	public long getProduct_rating() {
		return product_rating;
	}

	public void setProduct_rating(long product_rating) {
		this.product_rating = product_rating;
	}
*/
	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Override
	public String toString() {
		return "FeedbackCommon [feedback_id=" + feedback_id + ", product_id=" + product_id + ", feedback=" + feedback
				+ "]";
	}

	

/*	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}*/

	
	
	

}
