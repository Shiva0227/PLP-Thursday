package com.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class CapStoreProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreProjectApplication.class, args);
	}

}
